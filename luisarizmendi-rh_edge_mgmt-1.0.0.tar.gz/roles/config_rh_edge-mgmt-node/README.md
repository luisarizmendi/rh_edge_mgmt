
# config_rh_edge-mgmt-node role


### Ansible Collections

You need to have a couple of Collections installed on your laptop:

```bash
ansible-galaxy collection install -f redhat_cop.controller_configuration --upgrade
ansible-galaxy collection install -f infra.eda_configuration --upgrade
```




